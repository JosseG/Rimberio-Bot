namespace MyBotConversational
{
    public class CitaCDetalles
    {
        public string idcita { get; set; }

    }
}
