namespace MyBotConversational
{
    public class CitaVDetalles
    {

        public string idcita { get; set; }

        public string username { get; set; }
        public long idUsuario { get; set; }
    }
}
