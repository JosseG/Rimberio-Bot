namespace MyBotConversational
{
    public class CitaVDetalles
    {

        public string idcita { get; set; }
    }
}
