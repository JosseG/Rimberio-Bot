﻿namespace MyBotConversational.Interfaces
{
    public interface IOpenAISettingsService
    {

        string GetApiKey();
    }
}
