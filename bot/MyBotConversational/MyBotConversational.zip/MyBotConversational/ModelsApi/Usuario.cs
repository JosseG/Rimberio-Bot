﻿using System.Collections.Generic;

namespace MyBotConversational.ModelsApi
{
    public class Usuario
    {

        public long codigo { get; set; }
        public string nombre { get; set; }

        public string email { get; set; }
        /*List<Mascota> mascotas { get; set; }¨*/

    }
}
