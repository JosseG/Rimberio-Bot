﻿namespace MyBotConversational.ModelsApi
{
    public class Especialidad
    {
        public long Id { get; set; }
        public string descripcion { get; set; }
        public bool estado { get; set; }
    }
}
