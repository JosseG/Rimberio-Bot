﻿namespace MyBotConversational.ModelsApi
{
    public class Mascota
    {

        public long codigo { get; set; }
        public string nombre { get; set; }
        public Usuario usuario { get; set; }

    }
}
