﻿namespace MyBotConversational.ModelsApi
{
    public class UsuarioRol
    {

        public long id { get; set; }
        public Usuario usuario { get; set; }
        public Rol rol { get; set; }
    }
}
