﻿namespace MyBotConversational.ModelsApi
{
    public class Authority
    {
        public string authority {  get; set; }
    }
}
