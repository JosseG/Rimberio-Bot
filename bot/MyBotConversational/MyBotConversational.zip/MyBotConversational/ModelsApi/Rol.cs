﻿namespace MyBotConversational.ModelsApi
{
    public class Rol
    {

        public long id { get; set; }
        public string descripcion { get; set; }
    }
}
