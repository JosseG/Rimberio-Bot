﻿using System.Collections.Generic;

namespace MyBotConversational.ModelsApi
{
    public class Servicio
    {
        public long codigo { get; set; }
        public string tipo { get; set; }
        /*List<Medico> medicos { get; set; }*/

    }
}
